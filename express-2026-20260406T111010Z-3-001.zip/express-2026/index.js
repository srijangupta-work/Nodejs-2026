import express from 'express'
import path from 'path' 
const app = express();
const absPath = path.resolve('/Users/srijangupta/Documents/MEAN-2026/express-2026/view')

const publicPath = path.resolve('public');
app.use(express.static(publicPath)) 



app.get("/" ,(req,resp)=>{
    resp.sendFile(absPath +"/home.html")
})

// login 
app.get("/login" ,(req,resp)=>{
    resp.sendFile(absPath +"/login.html")
})

//submit
app.get("/submit" , (req,resp)=>{
    resp.write("Your Data is Submitted");
    resp.end()
})

// about
app.get("/about" ,(req,resp)=>{
    resp.sendFile(absPath+"/about.html")
})

// 404 page 
app.use((req,resp)=>{
    resp.status(404).sendFile(absPath+"/404.html");
})

app.listen(3200)