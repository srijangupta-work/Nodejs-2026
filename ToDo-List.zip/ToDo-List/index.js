import express from 'express';
import { MongoClient, ObjectId } from 'mongodb';
import path from 'path';
const app = express();

const publicpath = path.resolve("public");
app.use(express.static(publicpath))


// DATABASE CONNECTION
const dbname = "Node-Projects";
const collectionname = "Todo_List"
const url = "mongodb://localhost:27017"
const client = new MongoClient(url)

const connection = async () => {
    const connect = await client.connect();
    return connect.db(dbname);
}


app.set("view engine", "ejs")

app.get("/", async (req, resp) => {
    const db = await connection();
    const collection = db.collection(collectionname);
    const result = await collection.find().toArray();
    console.log(result);
    resp.render("list", { result });
});

app.get("/add", (req, resp) => {
    resp.render("add")
});
// app.get("update",(req,resp)=>{
//     resp.render("Update")
// })


//ADD DATA
app.use(express.urlencoded({ extended: false }));
app.post("/add", async (req, resp) => {
    const db = await connection();
    const collection = db.collection(collectionname)
    const result = collection.insertOne(req.body);
    if (result) {
        resp.redirect("/")
    } else {
        resp.redirect("/add")
    }
});


//DELETE DATA
app.get("/delete/:id", async (req, resp) => {
    const db = await connection();
    const collection = db.collection(collectionname)
    const result = collection.deleteOne({ _id: new ObjectId(req.params._id) });
    if (result) {
        resp.redirect("/")
    } else {
        resp.redirect("some error")
    }
});

//--------------UPDATE DATA---------------

// ---------fetching data-------------
app.get("/update/:_id", async (req, resp) => {
    console.log(req.params._id);
    if (!ObjectId.isValid(req.params._id)) {
        return resp.send("Invalid ObjectId");
    }
    const db = await connection();
    const collection = db.collection( collectionname);
    const result = await collection.findOne({_id:new ObjectId(req.params._id)});
    if (result) {
        resp.render("update",{ result });
    }
    else {
        resp.send( "Task not found");
    }
});

//---------------- update data ------------------
app.post("/update/:_id", async (req, resp) => {
    console.log(req.params._id);
    if (!ObjectId.isValid(req.params._id)) {
        return resp.send("Invalid ObjectId");
    }
    const db = await connection();
    const collection = db.collection( collectionname);
    const filter = {_id:new ObjectId(req.params._id)};
    const updateddata = {$set:{title:req.body.title , description :req.body.description}};
    const result = await collection.updateOne(filter,updateddata);
    if (result) {
        resp.redirect("/");
    }
    else {
        resp.send( "Task not found");
    }
});

app.listen(3200)